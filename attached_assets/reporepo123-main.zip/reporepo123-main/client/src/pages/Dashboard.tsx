import { useState } from "react";
import { Sidebar } from "@/components/Sidebar";
import { ConfigurationPanel } from "@/components/ConfigurationPanel";
import { ResultsPanel } from "@/components/ResultsPanel";
import { Button } from "@/components/ui/button";
import { MenuIcon } from "lucide-react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useScraperConfig, useScraperJobs } from "@/hooks/use-scraper";
import { useMobile } from "@/hooks/use-mobile";

export default function Dashboard() {
  const isMobile = useMobile();
  const [selectedConfigId, setSelectedConfigId] = useState<number | null>(null);
  const [showMobileSidebar, setShowMobileSidebar] = useState(false);
  const [activeTab, setActiveTab] = useState("config");
  
  const { data: selectedConfig, isLoading: isLoadingConfig } = useScraperConfig(selectedConfigId);
  const { data: scraperJobs, isLoading: isLoadingJobs } = useScraperJobs(selectedConfigId);
  
  const lastJob = scraperJobs && scraperJobs.length > 0 ? scraperJobs[0] : null;
  
  const toggleMobileSidebar = () => {
    setShowMobileSidebar(!showMobileSidebar);
  };
  
  const handleTabChange = (value: string) => {
    setActiveTab(value);
  };

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar - Hidden on mobile unless toggled */}
      <div className={`${isMobile ? 'absolute z-50 h-screen' : 'hidden md:flex md:flex-shrink-0'} ${showMobileSidebar ? 'block' : 'hidden md:block'}`}>
        <Sidebar isMobile={isMobile} onClose={() => setShowMobileSidebar(false)} />
      </div>

      {/* Main Content Area */}
      <div className="flex flex-col flex-1 w-0 overflow-hidden">
        {/* Mobile Header */}
        <div className="md:hidden pl-1 pt-1 sm:pl-3 sm:pt-3 bg-white shadow z-10">
          <Button variant="ghost" size="icon" onClick={toggleMobileSidebar}>
            <MenuIcon className="h-6 w-6 text-gray-500" />
          </Button>
        </div>
        
        {/* Main Tabs */}
        <div className="bg-white shadow-sm">
          <div className="px-4 sm:px-6 lg:px-8">
            <Tabs defaultValue="config" value={activeTab} onValueChange={handleTabChange} className="w-full">
              <TabsList className="w-full justify-start">
                <TabsTrigger value="config" className="flex-1 max-w-[200px]">
                  Scraper Configuration
                </TabsTrigger>
                <TabsTrigger value="data" className="flex-1 max-w-[200px]">
                  Data Management
                </TabsTrigger>
                <TabsTrigger value="export" className="flex-1 max-w-[200px]">
                  Export & Reports
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>

        {/* Two-panel Layout */}
        <div className="flex-1 flex overflow-hidden">
          {/* Configuration Panel */}
          {(!isMobile || activeTab === "config") && (
            <ConfigurationPanel 
              selectedConfigId={selectedConfigId} 
              onSelectConfig={setSelectedConfigId} 
            />
          )}

          {/* Results Panel */}
          {(!isMobile || activeTab === "data" || activeTab === "export") && (
            <ResultsPanel 
              selectedConfig={selectedConfig} 
              lastJob={lastJob}
              isLoadingConfig={isLoadingConfig}
            />
          )}
        </div>
      </div>
    </div>
  );
}
