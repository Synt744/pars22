import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { 
  ScraperConfig, 
  InsertScraperConfig, 
  DataField, 
  InsertDataField, 
  ScraperJob, 
  ScrapedProduct 
} from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

// Hook for scraper configurations
export function useScraperConfigs() {
  return useQuery<ScraperConfig[]>({
    queryKey: ['/api/configs'],
  });
}

export function useScraperConfig(id: number | null) {
  return useQuery<ScraperConfig>({
    queryKey: ['/api/configs', id],
    enabled: id !== null,
  });
}

export function useCreateScraperConfig() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (config: InsertScraperConfig) => {
      const res = await apiRequest('POST', '/api/configs', config);
      return await res.json() as ScraperConfig;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/configs'] });
      toast({
        title: "Success",
        description: "Scraper configuration created successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create configuration",
        variant: "destructive",
      });
    },
  });
}

export function useUpdateScraperConfig() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ id, config }: { id: number, config: Partial<InsertScraperConfig> }) => {
      const res = await apiRequest('PATCH', `/api/configs/${id}`, config);
      return await res.json() as ScraperConfig;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['/api/configs'] });
      queryClient.invalidateQueries({ queryKey: ['/api/configs', variables.id] });
      toast({
        title: "Success",
        description: "Configuration updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update configuration",
        variant: "destructive",
      });
    },
  });
}

export function useDeleteScraperConfig() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/configs/${id}`);
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/configs'] });
      toast({
        title: "Success",
        description: "Configuration deleted successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete configuration",
        variant: "destructive",
      });
    },
  });
}

// Hook for data fields
export function useDataFields(configId: number | null) {
  return useQuery<DataField[]>({
    queryKey: ['/api/configs', configId, 'fields'],
    enabled: configId !== null,
  });
}

export function useCreateDataField() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (field: InsertDataField) => {
      const res = await apiRequest('POST', '/api/fields', field);
      return await res.json() as DataField;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/configs', data.configId, 'fields'] });
      toast({
        title: "Success",
        description: "Data field added successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to add data field",
        variant: "destructive",
      });
    },
  });
}

export function useUpdateDataField() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ id, field, configId }: { id: number, field: Partial<InsertDataField>, configId: number }) => {
      const res = await apiRequest('PATCH', `/api/fields/${id}`, field);
      return { data: await res.json() as DataField, configId };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/configs', data.configId, 'fields'] });
      toast({
        title: "Success",
        description: "Data field updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update data field",
        variant: "destructive",
      });
    },
  });
}

export function useDeleteDataField() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ id, configId }: { id: number, configId: number }) => {
      await apiRequest('DELETE', `/api/fields/${id}`);
      return { id, configId };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/configs', data.configId, 'fields'] });
      toast({
        title: "Success",
        description: "Data field deleted successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete data field",
        variant: "destructive",
      });
    },
  });
}

// Hook for scraping
export function useStartScraping() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (configId: number) => {
      const res = await apiRequest('POST', `/api/configs/${configId}/scrape`, {});
      return await res.json();
    },
    onSuccess: (_, configId) => {
      queryClient.invalidateQueries({ queryKey: ['/api/configs', configId, 'jobs'] });
      queryClient.invalidateQueries({ queryKey: ['/api/jobs/recent'] });
      toast({
        title: "Scraping Started",
        description: "The scraping process has been initiated",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to start scraping",
        variant: "destructive",
      });
    },
  });
}

// Hook for scraper jobs
export function useScraperJobs(configId: number | null) {
  return useQuery<ScraperJob[]>({
    queryKey: ['/api/configs', configId, 'jobs'],
    enabled: configId !== null,
  });
}

export function useRecentJobs() {
  return useQuery<ScraperJob[]>({
    queryKey: ['/api/jobs/recent'],
  });
}

// Hook for scraped products
export interface ProductsResponse {
  products: ScrapedProduct[];
  total: number;
  limit: number;
  offset: number;
}

export function useScrapedProducts(configId: number | null, limit = 20, offset = 0, search = "") {
  const params = new URLSearchParams();
  params.append('limit', limit.toString());
  params.append('offset', offset.toString());
  if (search) params.append('search', search);
  
  return useQuery<ProductsResponse>({
    queryKey: ['/api/configs', configId, 'products', { limit, offset, search }],
    enabled: configId !== null,
  });
}

// Hook for exporting data
export function useExportData(format: 'csv' | 'json') {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (configId: number) => {
      window.location.href = `/api/configs/${configId}/export/${format}`;
      return true;
    },
    onError: (error) => {
      toast({
        title: "Export Error",
        description: error instanceof Error ? error.message : `Failed to export as ${format.toUpperCase()}`,
        variant: "destructive",
      });
    },
  });
}
