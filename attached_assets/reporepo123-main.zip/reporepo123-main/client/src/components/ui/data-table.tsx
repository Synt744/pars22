import { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ScrapedProduct } from "@shared/schema";
import { 
  ChevronLeftIcon, 
  ChevronRightIcon, 
  SearchIcon, 
  FilterIcon, 
  EyeIcon, 
  PencilIcon, 
  TrashIcon 
} from "lucide-react";

interface DataTableProps {
  products: ScrapedProduct[];
  total: number;
  loading: boolean;
  pageSize: number;
  currentPage: number;
  onPageChange: (page: number) => void;
  onSearch: (term: string) => void;
  onDelete: (id: number) => void;
  onCategoryFilter: (category: string) => void;
  onPriceFilter: (range: string) => void;
}

export function DataTable({
  products,
  total,
  loading,
  pageSize,
  currentPage,
  onPageChange,
  onSearch,
  onDelete,
  onCategoryFilter,
  onPriceFilter
}: DataTableProps) {
  const [searchTerm, setSearchTerm] = useState("");
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchTerm);
  };
  
  const startItem = (currentPage - 1) * pageSize + 1;
  const endItem = Math.min(currentPage * pageSize, total);
  const totalPages = Math.ceil(total / pageSize);
  
  const renderPaginationButtons = () => {
    const buttons = [];
    
    if (totalPages <= 5) {
      for (let i = 1; i <= totalPages; i++) {
        buttons.push(
          <Button
            key={i}
            variant={currentPage === i ? "default" : "outline"}
            size="sm"
            className={`w-9 ${currentPage === i ? "text-white" : ""}`}
            onClick={() => onPageChange(i)}
          >
            {i}
          </Button>
        );
      }
    } else {
      // Always show first page
      buttons.push(
        <Button
          key={1}
          variant={currentPage === 1 ? "default" : "outline"}
          size="sm"
          className={`w-9 ${currentPage === 1 ? "text-white" : ""}`}
          onClick={() => onPageChange(1)}
        >
          1
        </Button>
      );
      
      // Calculate range of pages to show around current page
      let startPage = Math.max(2, currentPage - 1);
      let endPage = Math.min(totalPages - 1, currentPage + 1);
      
      // Adjust if we're near the beginning
      if (currentPage <= 3) {
        endPage = Math.min(4, totalPages - 1);
      }
      
      // Adjust if we're near the end
      if (currentPage >= totalPages - 2) {
        startPage = Math.max(totalPages - 3, 2);
      }
      
      // Show ellipsis if there's a gap after page 1
      if (startPage > 2) {
        buttons.push(
          <span key="ellipsis1" className="px-2">...</span>
        );
      }
      
      // Show pages around current page
      for (let i = startPage; i <= endPage; i++) {
        buttons.push(
          <Button
            key={i}
            variant={currentPage === i ? "default" : "outline"}
            size="sm"
            className={`w-9 ${currentPage === i ? "text-white" : ""}`}
            onClick={() => onPageChange(i)}
          >
            {i}
          </Button>
        );
      }
      
      // Show ellipsis if there's a gap before last page
      if (endPage < totalPages - 1) {
        buttons.push(
          <span key="ellipsis2" className="px-2">...</span>
        );
      }
      
      // Always show last page
      buttons.push(
        <Button
          key={totalPages}
          variant={currentPage === totalPages ? "default" : "outline"}
          size="sm"
          className={`w-9 ${currentPage === totalPages ? "text-white" : ""}`}
          onClick={() => onPageChange(totalPages)}
        >
          {totalPages}
        </Button>
      );
    }
    
    return buttons;
  };

  const renderStars = (rating: string | null) => {
    if (!rating) return null;
    
    const numRating = parseFloat(rating);
    const stars = [];
    
    for (let i = 1; i <= 5; i++) {
      if (i <= numRating) {
        stars.push(<i key={i} className="ri-star-fill text-yellow-400"></i>);
      } else if (i - 0.5 <= numRating) {
        stars.push(<i key={i} className="ri-star-half-fill text-yellow-400"></i>);
      } else {
        stars.push(<i key={i} className="ri-star-line text-yellow-400"></i>);
      }
    }
    
    return <div className="flex text-xs">{stars}</div>;
  };

  return (
    <div className="space-y-4">
      {/* Filter Bar */}
      <div className="bg-white p-3 rounded-lg shadow-sm flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3 items-center">
        <form onSubmit={handleSearch} className="relative w-full sm:w-64">
          <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            type="text"
            placeholder="Search products..."
            className="pl-10 pr-3 py-2"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </form>
        
        <div className="flex space-x-2 w-full sm:w-auto">
          <Select onValueChange={onCategoryFilter}>
            <SelectTrigger className="w-full sm:w-auto text-sm">
              <SelectValue placeholder="All Categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All Categories</SelectItem>
              <SelectItem value="Electronics">Electronics</SelectItem>
              <SelectItem value="Home & Kitchen">Home & Kitchen</SelectItem>
              <SelectItem value="Art & Crafts">Art & Crafts</SelectItem>
            </SelectContent>
          </Select>
          
          <Select onValueChange={onPriceFilter}>
            <SelectTrigger className="w-full sm:w-auto text-sm">
              <SelectValue placeholder="Price: All" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">Price: All</SelectItem>
              <SelectItem value="under25">Under $25</SelectItem>
              <SelectItem value="25to50">$25 - $50</SelectItem>
              <SelectItem value="50to100">$50 - $100</SelectItem>
              <SelectItem value="over100">Over $100</SelectItem>
            </SelectContent>
          </Select>
          
          <Button 
            variant="outline" 
            size="icon" 
            className="h-10 w-10"
            title="More Filters"
          >
            <FilterIcon className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Results Table */}
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[300px]">
                  <div className="flex items-center space-x-1">
                    <span>Product</span>
                    <ChevronLeftIcon className="h-4 w-4" />
                  </div>
                </TableHead>
                <TableHead>
                  <div className="flex items-center space-x-1">
                    <span>Price</span>
                    <ChevronLeftIcon className="h-4 w-4" />
                  </div>
                </TableHead>
                <TableHead>
                  <div className="flex items-center space-x-1">
                    <span>Rating</span>
                    <ChevronLeftIcon className="h-4 w-4" />
                  </div>
                </TableHead>
                <TableHead>Category</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                Array(5).fill(0).map((_, i) => (
                  <TableRow key={i}>
                    <TableCell>
                      <div className="flex items-center">
                        <div className="h-10 w-10 bg-gray-100 rounded animate-pulse"></div>
                        <div className="ml-4 space-y-1">
                          <div className="h-4 w-48 bg-gray-100 rounded animate-pulse"></div>
                          <div className="h-3 w-32 bg-gray-100 rounded animate-pulse"></div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="h-4 w-16 bg-gray-100 rounded animate-pulse"></div>
                    </TableCell>
                    <TableCell>
                      <div className="h-4 w-24 bg-gray-100 rounded animate-pulse"></div>
                    </TableCell>
                    <TableCell>
                      <div className="h-6 w-24 bg-gray-100 rounded animate-pulse"></div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end space-x-2">
                        <div className="h-8 w-8 bg-gray-100 rounded animate-pulse"></div>
                        <div className="h-8 w-8 bg-gray-100 rounded animate-pulse"></div>
                        <div className="h-8 w-8 bg-gray-100 rounded animate-pulse"></div>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : products.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8 text-gray-500">
                    No products found. Try adjusting your search or run a scraper.
                  </TableCell>
                </TableRow>
              ) : (
                products.map((product) => (
                  <TableRow key={product.id} className="hover:bg-gray-50">
                    <TableCell>
                      <div className="flex items-center">
                        <div className="h-10 w-10 flex-shrink-0 bg-gray-100 rounded">
                          <div className="h-full w-full flex items-center justify-center text-gray-500">
                            <i className="ri-image-line"></i>
                          </div>
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">{product.title}</div>
                          <div className="text-xs text-gray-500 truncate max-w-xs">{product.description}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm text-gray-900">{product.price}</div>
                      <div className="text-xs text-success">{product.inStock ? "In stock" : "Out of stock"}</div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <div className="text-sm font-medium text-gray-900 mr-1">{product.rating}</div>
                        {renderStars(product.rating)}
                      </div>
                      <div className="text-xs text-gray-500">{product.reviewCount} reviews</div>
                    </TableCell>
                    <TableCell>
                      {product.category && (
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-primary-light text-primary">
                          {product.category}
                        </span>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end space-x-2">
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <EyeIcon className="h-4 w-4 text-gray-500" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <PencilIcon className="h-4 w-4 text-gray-500" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8"
                          onClick={() => onDelete(product.id)}
                        >
                          <TrashIcon className="h-4 w-4 text-red-500" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
        
        {/* Pagination */}
        {total > 0 && (
          <div className="px-4 py-3 flex items-center justify-between border-t border-gray-200">
            <div className="flex-1 flex justify-between sm:hidden">
              <Button
                variant="outline"
                size="sm"
                onClick={() => onPageChange(Math.max(1, currentPage - 1))}
                disabled={currentPage === 1}
              >
                Previous
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onPageChange(Math.min(totalPages, currentPage + 1))}
                disabled={currentPage === totalPages}
              >
                Next
              </Button>
            </div>
            <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
              <div>
                <p className="text-sm text-gray-700">
                  Showing <span className="font-medium">{startItem}</span> to{" "}
                  <span className="font-medium">{endItem}</span> of{" "}
                  <span className="font-medium">{total}</span> results
                </p>
              </div>
              <div>
                <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">
                  <Button
                    variant="outline"
                    size="sm"
                    className="rounded-l-md"
                    onClick={() => onPageChange(Math.max(1, currentPage - 1))}
                    disabled={currentPage === 1}
                  >
                    <span className="sr-only">Previous</span>
                    <ChevronLeftIcon className="h-5 w-5" />
                  </Button>
                  
                  {renderPaginationButtons()}
                  
                  <Button
                    variant="outline"
                    size="sm"
                    className="rounded-r-md"
                    onClick={() => onPageChange(Math.min(totalPages, currentPage + 1))}
                    disabled={currentPage === totalPages}
                  >
                    <span className="sr-only">Next</span>
                    <ChevronRightIcon className="h-5 w-5" />
                  </Button>
                </nav>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
