import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PlusIcon, TrashIcon, PencilIcon } from "lucide-react";
import { InsertDataField, DataField } from "@shared/schema";
import { useCreateDataField, useUpdateDataField, useDeleteDataField } from "@/hooks/use-scraper";

interface FieldSelectorProps {
  configId: number;
  fields: DataField[];
  isLoading: boolean;
}

export function FieldSelector({ configId, fields, isLoading }: FieldSelectorProps) {
  const [open, setOpen] = useState(false);
  const [editField, setEditField] = useState<DataField | null>(null);
  const [name, setName] = useState("");
  const [selector, setSelector] = useState("");
  const [status, setStatus] = useState<string>("active");
  
  const createField = useCreateDataField();
  const updateField = useUpdateDataField();
  const deleteField = useDeleteDataField();

  const resetForm = () => {
    setName("");
    setSelector("");
    setStatus("active");
    setEditField(null);
  };

  const handleOpenChange = (open: boolean) => {
    setOpen(open);
    if (!open) resetForm();
  };

  const handleEdit = (field: DataField) => {
    setEditField(field);
    setName(field.name);
    setSelector(field.selector);
    setStatus(field.status);
    setOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const fieldData: InsertDataField = {
      name,
      selector,
      status,
      configId
    };
    
    if (editField) {
      updateField.mutate({
        id: editField.id,
        field: fieldData,
        configId
      });
    } else {
      createField.mutate(fieldData);
    }
    
    setOpen(false);
    resetForm();
  };

  const handleDelete = (id: number) => {
    if (window.confirm("Are you sure you want to delete this field?")) {
      deleteField.mutate({ id, configId });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-500";
      case "warning":
        return "bg-yellow-500";
      default:
        return "bg-gray-500";
    }
  };

  return (
    <div>
      <div className="flex justify-between mb-2">
        <Label>Data Fields</Label>
        <Dialog open={open} onOpenChange={handleOpenChange}>
          <DialogTrigger asChild>
            <Button variant="ghost" size="sm" className="text-xs text-primary flex items-center">
              <PlusIcon className="h-3 w-3 mr-1" />
              Add Field
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editField ? "Edit Field" : "Add New Field"}</DialogTitle>
              <DialogDescription>
                Define the data field to extract from the target site.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit}>
              <div className="space-y-4 py-4">
                <div className="grid w-full gap-1.5">
                  <Label htmlFor="name">Field Name</Label>
                  <Input 
                    id="name" 
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Product Title" 
                    required
                  />
                </div>
                <div className="grid w-full gap-1.5">
                  <Label htmlFor="selector">CSS Selector</Label>
                  <Input 
                    id="selector" 
                    value={selector}
                    onChange={(e) => setSelector(e.target.value)}
                    placeholder="e.g. .product-title h1" 
                    required
                  />
                </div>
                <div className="grid w-full gap-1.5">
                  <Label htmlFor="status">Status</Label>
                  <Select value={status} onValueChange={setStatus}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="warning">Warning</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button type="submit" disabled={createField.isPending || updateField.isPending}>
                  {editField ? "Update Field" : "Add Field"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      
      {isLoading ? (
        <div className="space-y-2">
          <div className="h-16 bg-gray-100 rounded animate-pulse"></div>
          <div className="h-16 bg-gray-100 rounded animate-pulse"></div>
        </div>
      ) : fields.length === 0 ? (
        <div className="bg-gray-50 rounded-md p-3 text-center">
          <p className="text-sm text-gray-500">No data fields defined yet.</p>
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" className="mt-2">
                <PlusIcon className="h-4 w-4 mr-1" />
                Add your first field
              </Button>
            </DialogTrigger>
          </Dialog>
        </div>
      ) : (
        <div className="space-y-2">
          {fields.map((field) => (
            <div key={field.id} className="bg-gray-50 rounded-md p-3">
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center">
                  <span className={`w-3 h-3 ${getStatusColor(field.status)} rounded-full mr-2`}></span>
                  <h3 className="text-sm font-medium">{field.name}</h3>
                </div>
                <div className="flex space-x-1">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-6 w-6" 
                    onClick={() => handleEdit(field)}
                  >
                    <PencilIcon className="h-3 w-3 text-gray-500" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-6 w-6" 
                    onClick={() => handleDelete(field.id)}
                  >
                    <TrashIcon className="h-3 w-3 text-gray-500" />
                  </Button>
                </div>
              </div>
              <div className="text-xs text-gray-500">
                Selector: <code className="bg-gray-200 px-1 py-0.5 rounded">{field.selector}</code>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
