import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandSeparator,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  CheckIcon, 
  ChevronsUpDownIcon, 
  SmartphoneIcon, 
  MonitorIcon, 
  RefreshCwIcon
} from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

// Enhanced list of user agents by category
const userAgents = {
  desktop: {
    chrome: [
      {
        value: "chrome_windows_latest",
        label: "Chrome (Windows) Latest",
        agent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"
      },
      {
        value: "chrome_mac_latest",
        label: "Chrome (Mac) Latest",
        agent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"
      },
      {
        value: "chrome_linux_latest",
        label: "Chrome (Linux) Latest",
        agent: "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"
      },
      {
        value: "chrome_windows_stable",
        label: "Chrome (Windows) Stable",
        agent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36"
      }
    ],
    firefox: [
      {
        value: "firefox_windows_latest",
        label: "Firefox (Windows) Latest",
        agent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/119.0"
      },
      {
        value: "firefox_mac_latest",
        label: "Firefox (Mac) Latest",
        agent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/119.0"
      },
      {
        value: "firefox_linux_latest",
        label: "Firefox (Linux) Latest",
        agent: "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/119.0"
      }
    ],
    safari: [
      {
        value: "safari_mac_latest",
        label: "Safari (Mac) Latest",
        agent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15"
      },
      {
        value: "safari_mac_stable",
        label: "Safari (Mac) Stable",
        agent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Safari/605.1.15"
      }
    ],
    edge: [
      {
        value: "edge_windows_latest",
        label: "Edge (Windows) Latest",
        agent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0"
      },
      {
        value: "edge_mac_latest",
        label: "Edge (Mac) Latest",
        agent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0"
      }
    ]
  },
  mobile: {
    ios: [
      {
        value: "safari_ios_17",
        label: "Safari (iOS 17)",
        agent: "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"
      },
      {
        value: "safari_ios_16",
        label: "Safari (iOS 16)",
        agent: "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1"
      },
      {
        value: "safari_ipad_17",
        label: "Safari (iPad OS 17)",
        agent: "Mozilla/5.0 (iPad; CPU OS 17_0_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"
      }
    ],
    android: [
      {
        value: "chrome_android_14",
        label: "Chrome (Android 14)",
        agent: "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36"
      },
      {
        value: "chrome_samsung_13",
        label: "Chrome (Samsung Galaxy)",
        agent: "Mozilla/5.0 (Linux; Android 13; SM-S901U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36"
      },
      {
        value: "chrome_android_13",
        label: "Chrome (Android 13)",
        agent: "Mozilla/5.0 (Linux; Android 13; SM-A536B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36"
      }
    ]
  }
};

// Function to get all user agents as a flat array
function getAllUserAgents() {
  const allAgents: any[] = [];
  
  // Add desktop agents
  Object.keys(userAgents.desktop).forEach(browser => {
    userAgents.desktop[browser as keyof typeof userAgents.desktop].forEach(agent => {
      allAgents.push(agent);
    });
  });
  
  // Add mobile agents
  Object.keys(userAgents.mobile).forEach(os => {
    userAgents.mobile[os as keyof typeof userAgents.mobile].forEach(agent => {
      allAgents.push(agent);
    });
  });
  
  return allAgents;
}

// Get a random user agent
function getRandomUserAgent() {
  const allAgents = getAllUserAgents();
  return allAgents[Math.floor(Math.random() * allAgents.length)];
}

interface UserAgentSelectorProps {
  value?: string;
  onSelect: (value: string) => void;
}

export function UserAgentSelector({ value, onSelect }: UserAgentSelectorProps) {
  const [open, setOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("desktop");
  
  const flatUserAgents = getAllUserAgents();
  const selectedAgent = flatUserAgents.find(
    (agent) => agent.agent === value
  );

  return (
    <div className="space-y-2">
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            role="combobox"
            aria-expanded={open}
            className="w-full justify-between dark:border-gray-600 dark:bg-gray-800 dark:text-gray-200"
          >
            {selectedAgent ? (
              <span className="line-clamp-1 text-left">
                {selectedAgent.label}
              </span>
            ) : (
              "Select User Agent..."
            )}
            <ChevronsUpDownIcon className="ml-2 h-4 w-4 shrink-0 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[360px] p-0" align="start">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <div className="flex items-center p-2 border-b dark:border-gray-700">
              <TabsList className="w-full dark:bg-gray-800">
                <TabsTrigger value="desktop" className="flex items-center gap-1 w-full">
                  <MonitorIcon className="h-4 w-4" />
                  <span>Desktop</span>
                </TabsTrigger>
                <TabsTrigger value="mobile" className="flex items-center gap-1 w-full">
                  <SmartphoneIcon className="h-4 w-4" />
                  <span>Mobile</span>
                </TabsTrigger>
              </TabsList>
              <Button 
                variant="ghost" 
                size="icon" 
                className="ml-2 rounded-full h-8 w-8 dark:text-gray-300 dark:hover:bg-gray-700"
                onClick={() => {
                  const randomAgent = getRandomUserAgent();
                  onSelect(randomAgent.agent);
                  setOpen(false);
                }}
                title="Pick random user agent"
              >
                <RefreshCwIcon className="h-4 w-4" />
              </Button>
            </div>
            
            <Command>
              <CommandInput placeholder="Search user agents..." className="dark:bg-gray-800 dark:text-gray-200" />
              <CommandEmpty className="dark:text-gray-400">No user agent found.</CommandEmpty>
              
              <TabsContent value="desktop" className="max-h-[300px] overflow-y-auto">
                {Object.keys(userAgents.desktop).map((browser) => (
                  <div key={browser}>
                    <CommandGroup heading={browser.charAt(0).toUpperCase() + browser.slice(1)}>
                      {userAgents.desktop[browser as keyof typeof userAgents.desktop].map((agent) => (
                        <CommandItem
                          key={agent.value}
                          value={agent.value}
                          onSelect={() => {
                            onSelect(agent.agent);
                            setOpen(false);
                          }}
                          className="dark:text-gray-200 dark:hover:bg-gray-700"
                        >
                          <CheckIcon
                            className={cn(
                              "mr-2 h-4 w-4",
                              agent.agent === value ? "opacity-100" : "opacity-0"
                            )}
                          />
                          {agent.label}
                        </CommandItem>
                      ))}
                    </CommandGroup>
                    <CommandSeparator className="dark:bg-gray-700" />
                  </div>
                ))}
              </TabsContent>
              
              <TabsContent value="mobile" className="max-h-[300px] overflow-y-auto">
                {Object.keys(userAgents.mobile).map((os) => (
                  <div key={os}>
                    <CommandGroup heading={os === 'ios' ? 'iOS' : 'Android'}>
                      {userAgents.mobile[os as keyof typeof userAgents.mobile].map((agent) => (
                        <CommandItem
                          key={agent.value}
                          value={agent.value}
                          onSelect={() => {
                            onSelect(agent.agent);
                            setOpen(false);
                          }}
                          className="dark:text-gray-200 dark:hover:bg-gray-700"
                        >
                          <CheckIcon
                            className={cn(
                              "mr-2 h-4 w-4",
                              agent.agent === value ? "opacity-100" : "opacity-0"
                            )}
                          />
                          {agent.label}
                        </CommandItem>
                      ))}
                    </CommandGroup>
                    <CommandSeparator className="dark:bg-gray-700" />
                  </div>
                ))}
              </TabsContent>
            </Command>
          </Tabs>
        </PopoverContent>
      </Popover>
      
      <div className="text-xs text-gray-500 dark:text-gray-400">
        User Agent helps bypass detection by mimicking real browsers
      </div>
    </div>
  );
}
